# 🎓 MyChalkPad Master Agent

**AI-powered operations agent for India's #1 School ERP startup.**

One agent. Six brains. Zero hallucinations.

---

## 🧠 The Six Brains

| Brain | What it does |
|-------|-------------|
| 📁 CSV Processing | Validates, auto-fixes, and scores school CSV uploads |
| 🔥 Firebase Data | Queries real Firestore data — attendance, fees, marks |
| 📱 Parent SMS | Generates personalised messages and sends via Fast2SMS |
| 📊 Analytics | Cross-school BI — health scores, churn risk, daily reports |
| 🎯 Sales | Finds school leads, scores them, saves to Google Sheets |
| 📢 Marketing | Instagram, LinkedIn, Reel scripts, WhatsApp content |

---

## ⚡ Quick Start (Local)

### 1. Clone and enter the project
```bash
git clone <your-repo-url>
cd mychalkpad_master_agent
```

### 2. Create virtual environment
```bash
python -m venv venv
source venv/bin/activate          # Linux/Mac
# or
venv\Scripts\activate             # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure environment variables
```bash
cp .env.example .env
# Edit .env with your real API keys
```

### 5. Run the app
```bash
streamlit run app.py
```

Open http://localhost:8501 in your browser.

---

## 🔑 Required API Keys

### Groq (FREE — Required)
1. Go to https://console.groq.com
2. Create account → API Keys → Create Key
3. Copy key → paste as `GROQ_API_KEY` in `.env`

### Firebase (Required for school data)
1. Go to Firebase Console → Your Project
2. Project Settings → Service Accounts
3. Click "Generate new private key"
4. Download JSON file
5. Extract `project_id`, `private_key`, `client_email`
6. Paste into `.env`

### Fast2SMS (Required for SMS)
1. Go to https://www.fast2sms.com
2. Sign up → Dashboard → Dev API
3. Copy API key → paste as `FAST2SMS_API_KEY` in `.env`

### Serper (FREE 2500 searches/month — for Sales Brain)
1. Go to https://serper.dev
2. Sign up → API Key
3. Paste as `SERPER_API_KEY` in `.env`

### Google Sheets (for saving sales leads)
1. Google Cloud Console → Enable Sheets API
2. Create Service Account → Download JSON
3. Paste entire JSON as `GOOGLE_SHEETS_CREDENTIALS` in `.env`
4. Share your Google Sheet with the service account email
5. Copy Sheet ID from URL → paste as `GOOGLE_SHEET_ID`

---

## 🚀 Deploy on Railway.app

### Step 1 — Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/your-username/mychalkpad-agent.git
git push -u origin main
```

### Step 2 — Create Railway project
1. Go to https://railway.app
2. Click "New Project" → "Deploy from GitHub repo"
3. Select your repository
4. Railway auto-detects `railway.json` — no extra config needed

### Step 3 — Add environment variables
1. In Railway dashboard → Your Service → Variables tab
2. Add all variables from `.env.example` with real values
3. IMPORTANT: For `FIREBASE_PRIVATE_KEY`, replace `\n` with actual newlines

### Step 4 — Deploy
1. Click "Deploy" — Railway runs `pip install -r requirements.txt` automatically
2. Wait ~3 minutes for first deploy
3. Click the generated URL to open your app

### Step 5 — Custom domain (optional)
1. Railway Settings → Domains → Add custom domain
2. Follow DNS instructions

---

## 📁 Testing with Sample Data

The `sample_data/demo_school/` folder contains realistic test data:

```
students.csv   — 50 students, edge cases included
attendance.csv — 3 months of data, 3 low-attendance students
marks.csv      — 2 exam types, 2 at-risk students
fees.csv       — 5 defaulters, 8 partial payers
```

To test the CSV Processing Brain:
1. Open the app → expand "Upload CSV File"
2. Select `sample_data/demo_school/students.csv`
3. Choose type "students" → click "Process CSV Now"

The agent will find:
- 1 duplicate row (RAHUL SHARMA)
- 1 wrong date format (01/06/2020)
- 1 invalid class format (8th)
- 1 missing phone number
- Auto-fix most errors and return quality score

---

## 🧪 Running the 50 Test Questions

```python
import json
from master_agent import run_task

with open("sample_data/test_questions.json") as f:
    questions = json.load(f)

results = []
for q in questions[:10]:   # run first 10
    response = run_task(q["question"], school_id="demo_school_001")
    passed = all(kw.lower() in response.lower() for kw in q["expected_contains"])
    results.append({"id": q["id"], "passed": passed})
    print(f"Q{q['id']}: {'✅' if passed else '❌'} {q['question'][:50]}")
```

---

## 🤖 How the Agent Works

```
User types message
       ↓
app.py detects language (Hindi/English)
       ↓
master_agent.py builds CrewAI task
       ↓
LLM (Groq llama-3.3-70b) decides which tool to call
       ↓
Tool executes (CSV/Firebase/SMS/Analytics/Sales/Marketing)
       ↓
Result returned with:
  - Confidence score
  - Source citation
  - Feedback buttons
```

---

## ⏰ Automated Schedules

| Time | Task |
|------|------|
| Every day 8:00 AM | Morning report — all schools |
| Every day 6:00 PM | End-of-day summary |
| Every Monday 9:00 AM | Weekly analytics report |

Reports are saved to `output/` directory automatically.

---

## 🎨 Brand Colors

- **Navy**: `#1E3A5F`
- **Orange**: `#F97316`

---

## 🔒 Safety Features

- **No hallucination**: Agent refuses to invent Firebase data
- **Double verification**: All money amounts and percentages calculated twice
- **Confidence scoring**: Every response shows confidence %
- **Source citation**: Every data answer cites exact Firebase collection
- **Feedback loop**: User ratings saved to `feedback/feedback_log.json`

---

## 📞 Support

Built for MyChalkPad by AI Engineering.
Questions? Open an issue on GitHub.

---

*Powered by Groq llama-3.3-70b-versatile (FREE) · Firebase Firestore · CrewAI*
