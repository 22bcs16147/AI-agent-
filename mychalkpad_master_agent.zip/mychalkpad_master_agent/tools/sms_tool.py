"""
tools/sms_tool.py — Brain 3: Parent Communication Brain
─────────────────────────────────────────────────────────
Reads Firebase data, generates personalised SMS, sends via Fast2SMS,
logs delivery to Firebase sms_logs/ sub-collection.
"""

import json
import requests
from datetime import datetime
from typing import Optional

from crewai.tools import tool

from config.settings import (
    FAST2SMS_API_KEY, FIREBASE_PROJECT_ID,
    FIREBASE_PRIVATE_KEY, FIREBASE_CLIENT_EMAIL,
    LOW_ATTENDANCE_THRESHOLD,
)

# ── Firebase helper (reuse _get_db pattern) ───────────────────────────────────

_db = None

def _get_db():
    global _db
    if _db is not None:
        return _db
    try:
        import firebase_admin
        from firebase_admin import credentials, firestore
        if not firebase_admin._apps:
            cred_dict = {
                "type": "service_account",
                "project_id": FIREBASE_PROJECT_ID,
                "private_key": FIREBASE_PRIVATE_KEY,
                "client_email": FIREBASE_CLIENT_EMAIL,
                "token_uri": "https://oauth2.googleapis.com/token",
            }
            cred = credentials.Certificate(cred_dict)
            firebase_admin.initialize_app(cred)
        _db = firestore.client()
        return _db
    except Exception as exc:
        raise ConnectionError(f"Firebase connection failed. Error: {exc}")


def _get_collection(school_id: str, sub_collection: str) -> list[dict]:
    docs = _get_db().collection("schools").document(school_id).collection(sub_collection).stream()
    records = []
    for doc in docs:
        d = doc.to_dict()
        d["_id"] = doc.id
        records.append(d)
    return records


# ── SMS Message Templates ─────────────────────────────────────────────────────

def _fee_reminder_msg(student_name: str, amount: float, due_date: str, school_name: str) -> str:
    return (
        f"Dear Parent, this is a reminder that school fee of Rs.{amount:.0f} "
        f"for {student_name} is due on {due_date}. "
        f"Please pay at the earliest to avoid inconvenience. "
        f"- {school_name} via MyChalkPad"
    )


def _low_attendance_msg(student_name: str, pct: float, school_name: str) -> str:
    return (
        f"Dear Parent, {student_name}'s attendance has dropped to {pct:.1f}%, "
        f"which is below the required 75%. "
        f"Please ensure regular attendance. "
        f"- {school_name} via MyChalkPad"
    )


def _exam_schedule_msg(student_name: str, exam_type: str, start_date: str, school_name: str) -> str:
    return (
        f"Dear Parent, {exam_type.replace('_', ' ').title()} exams for {student_name} "
        f"begin on {start_date}. Please ensure your child is well-prepared. "
        f"Best wishes. - {school_name} via MyChalkPad"
    )


def _holiday_msg(holiday_name: str, holiday_date: str, school_name: str) -> str:
    return (
        f"Dear Parent, {school_name} will remain closed on {holiday_date} "
        f"on account of {holiday_name}. School resumes next working day. "
        f"- MyChalkPad"
    )


def _result_msg(student_name: str, exam_type: str, total_marks: float,
                max_marks: float, school_name: str) -> str:
    pct = round(total_marks / max_marks * 100, 1) if max_marks else 0
    return (
        f"Dear Parent, {student_name}'s {exam_type.replace('_', ' ').title()} results: "
        f"{total_marks:.0f}/{max_marks:.0f} ({pct}%). "
        f"Visit school portal for detailed marksheet. "
        f"- {school_name} via MyChalkPad"
    )


# ── Fast2SMS Sender ───────────────────────────────────────────────────────────

def _send_via_fast2sms(phone_numbers: list[str], message: str) -> dict:
    """
    Send SMS via Fast2SMS Developer API.
    Returns API response dict.
    """
    if not FAST2SMS_API_KEY:
        return {"success": False, "error": "FAST2SMS_API_KEY not configured in .env"}

    url = "https://www.fast2sms.com/dev/bulkV2"
    headers = {
        "authorization": FAST2SMS_API_KEY,
        "Content-Type": "application/json",
    }
    payload = {
        "route": "q",   # Transactional route
        "message": message,
        "language": "english",
        "flash": 0,
        "numbers": ",".join(phone_numbers),
    }

    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=15)
        data = resp.json()
        return {
            "success": data.get("return", False),
            "request_id": data.get("request_id", ""),
            "message": data.get("message", []),
            "status_code": resp.status_code,
        }
    except requests.exceptions.RequestException as exc:
        return {"success": False, "error": str(exc)}


def _save_sms_log(school_id: str, message: str, recipients_count: int, status: str):
    """Write an SMS log entry to Firebase sms_logs/ sub-collection."""
    try:
        db = _get_db()
        log_ref = (
            db.collection("schools")
              .document(school_id)
              .collection("sms_logs")
              .document()
        )
        log_ref.set({
            "message":          message,
            "recipients_count": recipients_count,
            "sent_at":          datetime.now().isoformat(),
            "status":           status,
        })
    except Exception as exc:
        pass   # non-critical — don't crash the tool


# ── Main Tool ─────────────────────────────────────────────────────────────────

@tool("Parent Communication Brain")
def send_sms(
    school_id: str,
    message_type: str,
    custom_message: Optional[str] = None,
    student_id: Optional[str] = None,
    extra_params: Optional[str] = None,
) -> str:
    """
    Generate and send SMS messages to parents.

    Args:
        school_id     : Firebase school document ID.
        message_type  : One of: fee_reminder / low_attendance / exam_schedule /
                        holiday / result / custom
        custom_message: Used only when message_type = custom.
        student_id    : If set, sends only to that student's parent.
        extra_params  : JSON string with additional params
                        e.g. '{"exam_type":"midterm","start_date":"2026-03-15"}'
                        or '{"holiday_name":"Holi","holiday_date":"2026-03-14"}'

    Returns:
        JSON string with delivery report, confidence, source, feedback prompt.
    """
    timestamp  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    params     = json.loads(extra_params) if extra_params else {}

    try:
        db = _get_db()
    except ConnectionError as ce:
        return json.dumps({"error": str(ce), "confidence": 0})

    # ── Fetch school name ────────────────────────────────────────────────────
    school_doc  = db.collection("schools").document(school_id).get()
    school_name = school_doc.to_dict().get("name", school_id) if school_doc.exists else school_id

    # ── Build recipient list ─────────────────────────────────────────────────
    students = _get_collection(school_id, "students")
    if student_id:
        students = [s for s in students if s["_id"] == student_id]

    if not students:
        return json.dumps({
            "error": (
                f"Data not found in Firebase.\n"
                f"Collection: schools/{school_id}/students\n"
                f"Query: student_id = {student_id or 'all'}\n"
                f"Please check Firebase console."
            ),
            "confidence": 0,
        })

    # ── Generate messages ─────────────────────────────────────────────────────
    mt = message_type.strip().lower()
    messages_sent: list[dict] = []

    if mt == "fee_reminder":
        fees = _get_collection(school_id, "fees")
        fees_map = {}
        for f in fees:
            sid = f.get("student_id", "")
            if f.get("status") in ("unpaid", "partial"):
                fees_map[sid] = f

        for stu in students:
            sid    = stu["_id"]
            phone  = str(stu.get("parent_phone", "")).strip()
            if sid not in fees_map or len(phone) != 10:
                continue
            fee  = fees_map[sid]
            msg  = _fee_reminder_msg(
                stu.get("name", "Student"),
                float(fee.get("amount", 0)) - float(fee.get("paid_amount", 0)),
                fee.get("due_date", "soon"),
                school_name,
            )
            messages_sent.append({"phone": phone, "student": stu.get("name", ""), "message": msg})

    elif mt == "low_attendance":
        att_records = _get_collection(school_id, "attendance")
        by_student: dict = {}
        for r in att_records:
            sid = r.get("student_id", "")
            by_student.setdefault(sid, {"total": 0, "present": 0})
            by_student[sid]["total"] += 1
            if r.get("status") == "present":
                by_student[sid]["present"] += 1

        for stu in students:
            sid   = stu["_id"]
            phone = str(stu.get("parent_phone", "")).strip()
            if sid not in by_student or len(phone) != 10:
                continue
            data  = by_student[sid]
            pct   = round(data["present"] / data["total"] * 100, 1) if data["total"] else 0
            if pct < LOW_ATTENDANCE_THRESHOLD:
                msg = _low_attendance_msg(stu.get("name", "Student"), pct, school_name)
                messages_sent.append({"phone": phone, "student": stu.get("name", ""), "message": msg})

    elif mt == "exam_schedule":
        exam_type  = params.get("exam_type", "upcoming")
        start_date = params.get("start_date", "soon")
        for stu in students:
            phone = str(stu.get("parent_phone", "")).strip()
            if len(phone) != 10:
                continue
            msg = _exam_schedule_msg(stu.get("name", "Student"), exam_type, start_date, school_name)
            messages_sent.append({"phone": phone, "student": stu.get("name", ""), "message": msg})

    elif mt == "holiday":
        holiday_name = params.get("holiday_name", "Holiday")
        holiday_date = params.get("holiday_date", "tomorrow")
        msg = _holiday_msg(holiday_name, holiday_date, school_name)
        for stu in students:
            phone = str(stu.get("parent_phone", "")).strip()
            if len(phone) == 10:
                messages_sent.append({"phone": phone, "student": stu.get("name", ""), "message": msg})

    elif mt == "result":
        marks_records = _get_collection(school_id, "marks")
        exam_type     = params.get("exam_type", "final")
        totals: dict  = {}
        max_totals: dict = {}
        for r in marks_records:
            if r.get("exam_type", "").lower() != exam_type.lower():
                continue
            sid = r.get("student_id", "")
            try:
                totals[sid]     = totals.get(sid, 0)     + float(r.get("marks", 0))
                max_totals[sid] = max_totals.get(sid, 0) + float(r.get("max_marks", 100))
            except (ValueError, TypeError):
                pass

        for stu in students:
            sid   = stu["_id"]
            phone = str(stu.get("parent_phone", "")).strip()
            if sid not in totals or len(phone) != 10:
                continue
            msg = _result_msg(
                stu.get("name", "Student"),
                exam_type,
                totals[sid],
                max_totals.get(sid, 100),
                school_name,
            )
            messages_sent.append({"phone": phone, "student": stu.get("name", ""), "message": msg})

    elif mt == "custom":
        if not custom_message:
            return json.dumps({"error": "custom_message is required for message_type=custom", "confidence": 0})
        for stu in students:
            phone = str(stu.get("parent_phone", "")).strip()
            if len(phone) == 10:
                messages_sent.append({"phone": phone, "student": stu.get("name", ""), "message": custom_message})

    else:
        return json.dumps({
            "error": f"Unknown message_type '{message_type}'. "
                     "Use: fee_reminder / low_attendance / exam_schedule / holiday / result / custom",
            "confidence": 0,
        })

    if not messages_sent:
        return json.dumps({
            "summary":    "No eligible recipients found for this message type.",
            "confidence": 85,
            "source":     f"Firebase schools/{school_id}/students. As of: {timestamp}",
            "feedback_prompt": "[✅ Correct] [❌ Wrong] [⚠️ Partial]",
        })

    # ── Batch-send (max 200 per API call) ────────────────────────────────────
    batch_size   = 200
    results      = []
    total_sent   = 0
    total_failed = 0

    # Group messages by unique message text to avoid duplicate API calls
    msg_groups: dict = {}
    for m in messages_sent:
        key = m["message"]
        msg_groups.setdefault(key, []).append(m["phone"])

    for msg_text, phones in msg_groups.items():
        for i in range(0, len(phones), batch_size):
            batch  = phones[i : i + batch_size]
            resp   = _send_via_fast2sms(batch, msg_text)
            if resp.get("success"):
                total_sent += len(batch)
                results.append({"batch_size": len(batch), "status": "sent", "request_id": resp.get("request_id")})
            else:
                total_failed += len(batch)
                results.append({"batch_size": len(batch), "status": "failed", "error": resp.get("error", "Unknown")})

    # ── Save log to Firebase ──────────────────────────────────────────────────
    last_msg_sample = messages_sent[0]["message"] if messages_sent else ""
    status_str      = "sent" if total_failed == 0 else ("partial" if total_sent > 0 else "failed")
    _save_sms_log(school_id, last_msg_sample, total_sent, status_str)

    delivery_report = {
        "message_type":     message_type,
        "total_recipients": len(messages_sent),
        "successfully_sent": total_sent,
        "failed":           total_failed,
        "batch_results":    results,
        "sample_message":   messages_sent[0]["message"] if messages_sent else "",
    }

    return json.dumps({
        "summary": (
            f"SMS Campaign Complete\n"
            f"Type: {message_type}\n"
            f"Total recipients: {len(messages_sent)}\n"
            f"Sent: {total_sent} ✅\n"
            f"Failed: {total_failed} ❌\n"
            f"Log saved to: Firebase schools/{school_id}/sms_logs/"
        ),
        "delivery_report":  delivery_report,
        "confidence":       92,
        "source": (
            f"Firebase schools/{school_id}/students + fees + attendance. "
            f"As of: {timestamp}"
        ),
        "timestamp":        timestamp,
        "feedback_prompt":  "[✅ Correct] [❌ Wrong] [⚠️ Partial]",
    }, ensure_ascii=False, indent=2)
