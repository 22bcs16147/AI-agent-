"""
master_agent.py — MyChalkPad Master Agent
──────────────────────────────────────────
One CrewAI Agent with 6 specialist tools (brains).
Uses Groq's free llama-3.3-70b-versatile model.
"""

import json
import os
from datetime import datetime
from typing import Optional

from crewai import Agent, Task, Crew, Process
from langchain_groq import ChatGroq

from config.settings import GROQ_API_KEY, GROQ_MODEL, FEEDBACK_LOG_PATH
from tools.csv_tool       import process_csv
from tools.firebase_tool  import query_firebase
from tools.sms_tool       import send_sms
from tools.analytics_tool import run_analytics
from tools.sales_tool     import find_leads
from tools.marketing_tool import create_content

# ── LLM ──────────────────────────────────────────────────────────────────────

def _get_llm():
    """Return a configured ChatGroq LLM instance."""
    if not GROQ_API_KEY:
        raise ValueError(
            "GROQ_API_KEY not found. Add it to your .env file. "
            "Get a free key at https://console.groq.com"
        )
    return ChatGroq(
        api_key=GROQ_API_KEY,
        model=GROQ_MODEL,
        temperature=0.1,   # low temperature for factual accuracy
    )


# ── Agent Builder ─────────────────────────────────────────────────────────────

def build_master_agent() -> Agent:
    """
    Build and return the MyChalkPad Master Agent with all 6 tools.
    """
    llm = _get_llm()

    agent = Agent(
        role="MyChalkPad Master Operations Agent",
        goal=(
            "Help MyChalkPad and its partner schools with data processing, "
            "analytics, parent communication, sales leads, and marketing content. "
            "Always cite sources, show confidence scores, and never invent data."
        ),
        backstory=(
            "You are the AI brain of MyChalkPad, an EdTech SaaS company serving "
            "Indian schools. You have 6 specialist tools:\n"
            "1. CSV Processing Brain — validate and fix school CSV uploads\n"
            "2. Firebase Data Brain — query real school data from Firestore\n"
            "3. Parent Communication Brain — generate and send SMS to parents\n"
            "4. Analytics Brain — cross-school business intelligence\n"
            "5. Sales Brain — find and score school leads\n"
            "6. Marketing Brain — create content for all channels\n\n"
            "Rules you ALWAYS follow:\n"
            "- Show Confidence: XX% at the top of every response\n"
            "- If confidence < 80%, warn the user to verify manually\n"
            "- Never invent Firebase data — only report what exists\n"
            "- Double-verify all monetary and percentage calculations\n"
            "- Show [✅ Correct] [❌ Wrong] [⚠️ Partial] feedback options\n"
            "- If user writes in Hindi, respond in Hindi"
        ),
        tools=[
            process_csv,
            query_firebase,
            send_sms,
            run_analytics,
            find_leads,
            create_content,
        ],
        llm=llm,
        verbose=True,
        allow_delegation=False,
        max_iter=5,
    )
    return agent


# ── Task Runner ───────────────────────────────────────────────────────────────

def run_task(
    user_input: str,
    school_id: Optional[str] = None,
    csv_content: Optional[str] = None,
    csv_type: Optional[str] = None,
) -> str:
    """
    Run a single task through the Master Agent.

    Args:
        user_input  : The user's question or instruction.
        school_id   : Firebase school ID (if relevant).
        csv_content : Raw CSV text (if user uploaded a file).
        csv_type    : Type of CSV (students/attendance/marks/fees/staff).

    Returns:
        Agent response as a string.
    """
    agent = build_master_agent()

    # Build context-rich task description
    context_parts = [f"User request: {user_input}"]
    if school_id:
        context_parts.append(f"School ID: {school_id}")
    if csv_content and csv_type:
        context_parts.append(f"CSV Type: {csv_type}")
        context_parts.append(f"CSV Content (first 500 chars): {csv_content[:500]}")

    task_description = "\n".join(context_parts)

    task = Task(
        description=task_description,
        expected_output=(
            "A complete, accurate response with:\n"
            "1. Confidence: XX% at the top\n"
            "2. Direct answer to the question\n"
            "3. Data source citation\n"
            "4. Feedback options: [✅ Correct] [❌ Wrong] [⚠️ Partial]\n"
        ),
        agent=agent,
    )

    crew = Crew(
        agents=[agent],
        tasks=[task],
        process=Process.sequential,
        verbose=False,
    )

    try:
        result = crew.kickoff()
        return str(result)
    except Exception as exc:
        error_msg = str(exc)
        if "groq" in error_msg.lower() or "api" in error_msg.lower():
            return (
                "AI service temporarily unavailable. Retrying in 30 seconds...\n"
                f"Error: {error_msg}"
            )
        return f"An error occurred: {error_msg}"


# ── Scheduled Report Runners ──────────────────────────────────────────────────

def run_morning_report() -> str:
    """Generate the daily 8 AM morning report across all schools."""
    agent  = build_master_agent()
    task   = Task(
        description=(
            "Generate the daily morning operations report for all MyChalkPad schools.\n"
            "Include:\n"
            "- Active vs inactive schools\n"
            "- Schools not marking attendance\n"
            "- Overdue complaints (7+ days)\n"
            "- High churn risk schools\n"
            "- Overall fee collection summary\n"
            "- Total students across all schools\n"
            "Use the Analytics Brain tool with report_type='morning'."
        ),
        expected_output="Formatted morning report with all KPIs and alerts.",
        agent=agent,
    )
    crew   = Crew(agents=[agent], tasks=[task], process=Process.sequential, verbose=False)
    try:
        return str(crew.kickoff())
    except Exception as exc:
        return f"Morning report failed: {exc}"


def run_eod_report() -> str:
    """Generate the daily 6 PM end-of-day summary."""
    agent  = build_master_agent()
    task   = Task(
        description=(
            "Generate the end-of-day summary for all MyChalkPad schools.\n"
            "Include fee collections today, SMS sent, attendance completion status.\n"
            "Use the Analytics Brain tool with report_type='eod'."
        ),
        expected_output="Formatted EOD summary.",
        agent=agent,
    )
    crew = Crew(agents=[agent], tasks=[task], process=Process.sequential, verbose=False)
    try:
        return str(crew.kickoff())
    except Exception as exc:
        return f"EOD report failed: {exc}"


def run_weekly_report() -> str:
    """Generate the Monday 9 AM weekly analytics report."""
    agent  = build_master_agent()
    task   = Task(
        description=(
            "Generate the weekly performance report for all MyChalkPad schools.\n"
            "Include school rankings by health score, attendance trends, "
            "fee collection rates, and churn risk analysis.\n"
            "Use the Analytics Brain tool with report_type='weekly'."
        ),
        expected_output="Formatted weekly analytics report.",
        agent=agent,
    )
    crew = Crew(agents=[agent], tasks=[task], process=Process.sequential, verbose=False)
    try:
        return str(crew.kickoff())
    except Exception as exc:
        return f"Weekly report failed: {exc}"


# ── Feedback Logger ───────────────────────────────────────────────────────────

def save_feedback(response_id: str, feedback: str, response_text: str):
    """
    Save user feedback (correct/wrong/partial) to local JSON log.
    Used for improving agent accuracy over time.
    """
    os.makedirs(os.path.dirname(FEEDBACK_LOG_PATH), exist_ok=True)

    try:
        with open(FEEDBACK_LOG_PATH, "r") as f:
            log = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        log = []

    log.append({
        "response_id":   response_id,
        "feedback":      feedback,
        "response_text": response_text[:500],
        "timestamp":     datetime.now().isoformat(),
    })

    with open(FEEDBACK_LOG_PATH, "w") as f:
        json.dump(log, f, indent=2, ensure_ascii=False)
