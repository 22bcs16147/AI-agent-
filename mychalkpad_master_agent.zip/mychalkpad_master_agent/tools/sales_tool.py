"""
tools/sales_tool.py — Brain 5: Sales Brain
────────────────────────────────────────────
Web-searches for school leads, scores them, generates outreach emails,
and saves to Google Sheets automatically.
"""

import json
import re
import requests
from datetime import datetime
from typing import Optional

from crewai.tools import tool

from config.settings import (
    SERPER_API_KEY,
    GOOGLE_SHEETS_CREDS,
    GOOGLE_SHEET_ID,
)

# ── Google Sheets helper ──────────────────────────────────────────────────────

def _get_sheets_service():
    """Return a Google Sheets API service object."""
    import json as _json
    from google.oauth2.service_account import Credentials
    from googleapiclient.discovery import build

    creds_dict = _json.loads(GOOGLE_SHEETS_CREDS) if isinstance(GOOGLE_SHEETS_CREDS, str) else GOOGLE_SHEETS_CREDS
    scopes     = ["https://www.googleapis.com/auth/spreadsheets"]
    creds      = Credentials.from_service_account_info(creds_dict, scopes=scopes)
    return build("sheets", "v4", credentials=creds)


def _append_to_sheet(rows: list[list]) -> bool:
    """Append rows to the configured Google Sheet. Returns True on success."""
    if not GOOGLE_SHEET_ID or not GOOGLE_SHEETS_CREDS or GOOGLE_SHEETS_CREDS == "{}":
        return False
    try:
        service = _get_sheets_service()
        body    = {"values": rows}
        service.spreadsheets().values().append(
            spreadsheetId=GOOGLE_SHEET_ID,
            range="Sheet1!A:Z",
            valueInputOption="RAW",
            body=body,
        ).execute()
        return True
    except Exception:
        return False


# ── Web Search ────────────────────────────────────────────────────────────────

def _serper_search(query: str) -> list[dict]:
    """Search Google via Serper API and return organic results."""
    if not SERPER_API_KEY:
        return []
    try:
        resp = requests.post(
            "https://google.serper.dev/search",
            json={"q": query, "gl": "in", "hl": "en", "num": 10},
            headers={"X-API-KEY": SERPER_API_KEY, "Content-Type": "application/json"},
            timeout=15,
        )
        data = resp.json()
        return data.get("organic", [])
    except Exception:
        return []


def _extract_phone(text: str) -> Optional[str]:
    """Extract first valid 10-digit phone number from text."""
    phones = re.findall(r"\b(?:\+91[-\s]?)?[6-9]\d{9}\b", text)
    for p in phones:
        digits = re.sub(r"\D", "", p)
        if digits.startswith("91") and len(digits) == 12:
            digits = digits[2:]
        if len(digits) == 10:
            return digits
    return None


def _extract_email(text: str) -> Optional[str]:
    """Extract first email from text."""
    match = re.search(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)
    return match.group(0) if match else None


def _estimate_school_size(snippet: str) -> str:
    """Estimate school size from search snippet text."""
    text = snippet.lower()
    if any(k in text for k in ["cbse", "icse", "cambridge", "international", "1000+ students"]):
        return "large (500+ students)"
    elif any(k in text for k in ["primary", "pre-school", "playschool", "100 students"]):
        return "small (<100 students)"
    return "medium (100-500 students)"


def _score_lead(school: dict) -> str:
    """Score a lead as HOT / WARM / COLD based on signals."""
    score = 0
    name  = (school.get("name", "") + " " + school.get("snippet", "")).lower()

    # HOT signals
    if school.get("phone"):            score += 30
    if school.get("email"):            score += 20
    if "cbse"  in name:                score += 15
    if "icse"  in name:                score += 15
    if "erp"   in name:                score += 10
    if "private" in name:              score += 5

    # WARM signals
    if school.get("website"):          score += 10
    if "school" in name:               score += 5

    if score >= 50:
        return "HOT"
    elif score >= 25:
        return "WARM"
    return "COLD"


def _generate_outreach_email(school: dict, city: str) -> str:
    """Generate a personalised cold outreach email for a school lead."""
    name    = school.get("name", "Your School")
    size    = school.get("estimated_size", "medium")
    website = school.get("website", "")

    return f"""Subject: Transform {name}'s Operations with MyChalkPad — Free Demo for {city} Schools

Dear Principal / Administration Team,

I hope this email finds you well. I came across {name} while researching leading schools in {city}, and I'd love to share how MyChalkPad can help you save 5+ hours daily on administrative tasks.

MyChalkPad is an all-in-one School ERP + Parent Communication App trusted by 50+ schools across India:

✅ Digital attendance with instant parent SMS alerts
✅ Fee management with automated payment reminders
✅ Student marks, report cards & rankings in one click
✅ Parent app for real-time communication
✅ Works offline — no internet needed in classrooms

Given your school size ({size}), you could realistically:
• Reduce fee follow-up time by 70%
• Eliminate manual attendance registers
• Send 1,000+ parent notifications in 30 seconds

We offer a completely FREE 30-day trial with full setup support — no credit card needed.

Could we schedule a 20-minute demo call this week? Reply to this email or WhatsApp us at +91-XXXXXXXXXX.

Best regards,
MyChalkPad Sales Team
www.mychalkpad.com

P.S. Mention this email to get 3 months free on your first annual plan.
"""


def _generate_followup_sequence(school_name: str) -> list[str]:
    """Return 3-email follow-up sequence."""
    return [
        f"[Follow-up 1 — Day 3] Hi, just checking if you had a chance to review our message about MyChalkPad for {school_name}. Happy to answer any questions!",
        f"[Follow-up 2 — Day 7] We recently helped a school similar to {school_name} reduce admin workload by 60%. Would love to share the case study — interested?",
        f"[Follow-up 3 — Day 14] Last message! We're offering a special end-of-term discount for {school_name} if you sign up before month-end. Reply 'DEMO' to book a call.",
    ]


# ── Main Tool ─────────────────────────────────────────────────────────────────

@tool("Sales Brain")
def find_leads(city: str, district: Optional[str] = None, limit: int = 10) -> str:
    """
    Search for school leads in a given city/district, score them,
    generate outreach emails, and save to Google Sheets.

    Args:
        city     : City name to search schools in (e.g., 'Pune', 'Jaipur').
        district : Optional district name to narrow search.
        limit    : Maximum number of leads to return (default 10).

    Returns:
        JSON string with leads list, outreach emails, confidence, source.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    location  = f"{city}, {district}" if district else city

    if not SERPER_API_KEY:
        return json.dumps({
            "error": "SERPER_API_KEY not configured. Add it to your .env file.",
            "confidence": 0,
        })

    # ── Search queries ────────────────────────────────────────────────────────
    queries = [
        f"CBSE private schools in {location}",
        f"ICSE schools {location} contact",
        f"best private schools {location} phone number",
    ]

    raw_results: list[dict] = []
    for q in queries:
        raw_results.extend(_serper_search(q))

    # ── De-duplicate by title ─────────────────────────────────────────────────
    seen_names: set = set()
    unique_results  = []
    for r in raw_results:
        name = r.get("title", "")
        if name not in seen_names and "school" in name.lower():
            seen_names.add(name)
            unique_results.append(r)
        if len(unique_results) >= limit:
            break

    # ── Build lead objects ────────────────────────────────────────────────────
    leads = []
    for r in unique_results:
        snippet  = r.get("snippet", "")
        combined = r.get("title", "") + " " + snippet + " " + r.get("link", "")

        lead = {
            "name":            r.get("title", "Unknown School").split(" - ")[0].strip(),
            "website":         r.get("link", ""),
            "address":         snippet[:120] if snippet else "N/A",
            "phone":           _extract_phone(combined),
            "email":           _extract_email(combined),
            "estimated_size":  _estimate_school_size(snippet),
            "city":            city,
            "snippet":         snippet[:200],
            "found_at":        timestamp,
        }
        lead["lead_score"] = _score_lead(lead)
        lead["outreach_email"] = _generate_outreach_email(lead, city)
        lead["followup_sequence"] = _generate_followup_sequence(lead["name"])
        leads.append(lead)

    # ── Sort: HOT first ───────────────────────────────────────────────────────
    score_order = {"HOT": 0, "WARM": 1, "COLD": 2}
    leads.sort(key=lambda x: score_order.get(x["lead_score"], 3))

    # ── Save to Google Sheets ─────────────────────────────────────────────────
    sheet_header = [["Name", "City", "Website", "Phone", "Email", "Size", "Score", "Found At"]]
    sheet_rows   = [
        [
            l["name"], l["city"], l["website"],
            l.get("phone", ""), l.get("email", ""),
            l["estimated_size"], l["lead_score"], l["found_at"],
        ]
        for l in leads
    ]
    saved_to_sheet = _append_to_sheet(sheet_header + sheet_rows)

    hot_count  = sum(1 for l in leads if l["lead_score"] == "HOT")
    warm_count = sum(1 for l in leads if l["lead_score"] == "WARM")
    cold_count = sum(1 for l in leads if l["lead_score"] == "COLD")

    return json.dumps({
        "summary": (
            f"Lead Search Complete — {location}\n"
            f"Total leads found : {len(leads)}\n"
            f"🔥 HOT  : {hot_count}\n"
            f"🟡 WARM : {warm_count}\n"
            f"🔵 COLD : {cold_count}\n"
            f"Saved to Google Sheets: {'✅ Yes' if saved_to_sheet else '❌ No (check GOOGLE_SHEETS_CREDENTIALS)'}"
        ),
        "leads":           leads,
        "confidence":      78,
        "confidence_note": "Web search results may be incomplete. Please verify phone numbers manually.",
        "source":          f"Google Search via Serper API. Query: schools in {location}. As of: {timestamp}",
        "timestamp":       timestamp,
        "feedback_prompt": "[✅ Correct] [❌ Wrong] [⚠️ Partial]",
    }, ensure_ascii=False, indent=2)
