"""
tools/firebase_tool.py — Brain 2: Firebase Data Brain
──────────────────────────────────────────────────────
Reads Firestore, answers questions about school data, never invents data.
Follows the Firebase schema from Part 2 of the brief exactly.
"""

import json
import os
from datetime import datetime, timedelta
from typing import Any, Optional

from crewai.tools import tool

from config.settings import (
    FIREBASE_PROJECT_ID, FIREBASE_PRIVATE_KEY, FIREBASE_CLIENT_EMAIL,
    LOW_ATTENDANCE_THRESHOLD, CONFIDENCE_MIN_THRESHOLD,
)

# ── Firebase initialisation (lazy singleton) ─────────────────────────────────

_db = None   # Firestore client, initialised once

def _get_db():
    """Return Firestore client, initialising it if needed."""
    global _db
    if _db is not None:
        return _db

    try:
        import firebase_admin
        from firebase_admin import credentials, firestore

        if not firebase_admin._apps:
            cred_dict = {
                "type": "service_account",
                "project_id": FIREBASE_PROJECT_ID,
                "private_key": FIREBASE_PRIVATE_KEY,
                "client_email": FIREBASE_CLIENT_EMAIL,
                "token_uri": "https://oauth2.googleapis.com/token",
            }
            cred = credentials.Certificate(cred_dict)
            firebase_admin.initialize_app(cred)

        _db = firestore.client()
        return _db

    except Exception as exc:
        raise ConnectionError(
            f"Firebase connection failed. Please check your internet and try again. "
            f"Error: {exc}"
        )


def _school_ref(school_id: str):
    """Return the Firestore DocumentReference for a school."""
    return _get_db().collection("schools").document(school_id)


def _get_collection(school_id: str, sub_collection: str) -> list[dict]:
    """Fetch all documents from a school sub-collection."""
    docs = _school_ref(school_id).collection(sub_collection).stream()
    records = []
    for doc in docs:
        d = doc.to_dict()
        d["_id"] = doc.id
        records.append(d)
    return records


# ── Sub-functions (called by the main tool) ───────────────────────────────────

def _get_school_info(school_id: str) -> dict:
    doc = _school_ref(school_id).get()
    if not doc.exists:
        return {}
    return doc.to_dict()


def _attendance_percentage(school_id: str, student_id: Optional[str] = None,
                           class_filter: Optional[str] = None,
                           section_filter: Optional[str] = None) -> dict:
    """
    Calculate attendance percentage.
    Double-verifies: runs the calculation twice and compares results.
    """
    records = _get_collection(school_id, "attendance")

    if student_id:
        records = [r for r in records if r.get("student_id") == student_id]
    if class_filter:
        records = [r for r in records if str(r.get("class", "")) == str(class_filter)]
    if section_filter:
        records = [r for r in records if r.get("section", "").upper() == section_filter.upper()]

    if not records:
        return {"error": "No attendance records found for the given filters."}

    # Run 1
    total1    = len(records)
    present1  = sum(1 for r in records if r.get("status") == "present")
    pct1      = round(present1 / total1 * 100, 2) if total1 else 0

    # Run 2 (independent re-count)
    total2    = sum(1 for _ in records)
    present2  = len([r for r in records if r.get("status") == "present"])
    pct2      = round(present2 / total2 * 100, 2) if total2 else 0

    if pct1 != pct2:
        return {
            "error": "Double-verification failed — results differ. Please check Firebase console.",
            "run1": pct1, "run2": pct2,
        }

    return {
        "total_records": total1,
        "present": present1,
        "absent": total1 - present1,
        "percentage": pct1,
        "verified": True,
    }


def _fee_defaulters(school_id: str) -> list[dict]:
    """Return students with unpaid or partial fees."""
    fees = _get_collection(school_id, "fees")
    return [f for f in fees if f.get("status") in ("unpaid", "partial")]


def _marks_analysis(school_id: str, class_filter: Optional[str] = None,
                    exam_type: Optional[str] = None) -> dict:
    """
    Marks summary with double-verification.
    Returns average, top scorers, students who failed 3+ subjects.
    """
    records = _get_collection(school_id, "marks")

    if class_filter:
        records = [r for r in records if str(r.get("class", "")) == str(class_filter)]
    if exam_type:
        records = [r for r in records if r.get("exam_type", "").lower() == exam_type.lower()]

    if not records:
        return {"error": "No marks records found."}

    numeric = [r for r in records if str(r.get("marks", "")).replace(".", "").isdigit()]

    # Double verify average
    def calc_avg(recs):
        vals = [float(r["marks"]) for r in recs]
        return round(sum(vals) / len(vals), 2) if vals else 0

    avg1 = calc_avg(numeric)
    avg2 = calc_avg(numeric)   # same set, independent call

    if abs(avg1 - avg2) > 0.001:
        return {"error": "Double-verification of average failed. Please check Firebase."}

    # Students who failed 3+ subjects (marks < 33)
    fails_per_student: dict = {}
    for r in numeric:
        sid   = r.get("student_id", "unknown")
        marks = float(r.get("marks", 0))
        mm    = float(r.get("max_marks", 100))
        pct   = (marks / mm * 100) if mm else 0
        if pct < 33:
            fails_per_student[sid] = fails_per_student.get(sid, 0) + 1

    at_risk = {sid: cnt for sid, cnt in fails_per_student.items() if cnt >= 3}

    return {
        "total_records":    len(records),
        "numeric_records":  len(numeric),
        "average_marks":    avg1,
        "verified":         True,
        "at_risk_students": at_risk,   # {student_id: fail_count}
    }


def _low_attendance_students(school_id: str) -> list[dict]:
    """Return students with attendance below LOW_ATTENDANCE_THRESHOLD."""
    records   = _get_collection(school_id, "attendance")
    students  = _get_collection(school_id, "students")
    student_map = {s["_id"]: s.get("name", s["_id"]) for s in students}

    by_student: dict = {}
    for r in records:
        sid = r.get("student_id", "")
        if sid not in by_student:
            by_student[sid] = {"total": 0, "present": 0}
        by_student[sid]["total"] += 1
        if r.get("status") == "present":
            by_student[sid]["present"] += 1

    low = []
    for sid, data in by_student.items():
        pct = round(data["present"] / data["total"] * 100, 2) if data["total"] else 0
        if pct < LOW_ATTENDANCE_THRESHOLD:
            low.append({
                "student_id":   sid,
                "student_name": student_map.get(sid, sid),
                "attendance_%": pct,
                "present_days": data["present"],
                "total_days":   data["total"],
            })
    return sorted(low, key=lambda x: x["attendance_%"])


# ── Main Tool ─────────────────────────────────────────────────────────────────

@tool("Firebase Data Brain")
def query_firebase(question: str, school_id: str, query_type: str = "general") -> str:
    """
    Query Firebase Firestore to answer questions about school data.

    Args:
        question   : Natural-language question about school data.
        school_id  : Firebase school document ID.
        query_type : One of: general / attendance / fees / marks /
                     students / staff / at_risk / complaints / sms_logs

    Returns:
        JSON string with answer, source, confidence, and feedback prompt.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    qt = query_type.strip().lower()

    try:
        db = _get_db()   # will raise ConnectionError if Firebase unreachable
    except ConnectionError as ce:
        return json.dumps({"error": str(ce), "confidence": 0})

    # ── Confirm school exists ─────────────────────────────────────────────────
    school_info = _get_school_info(school_id)
    if not school_info:
        return json.dumps({
            "error": (
                f"Data not found in Firebase.\n"
                f"Collection: schools\n"
                f"Query: school_id = {school_id}\n"
                f"Please check Firebase console."
            ),
            "confidence": 0,
        })

    school_name = school_info.get("name", school_id)
    result: Any = None
    confidence  = 90

    # ── Route to the right sub-function ──────────────────────────────────────
    if qt == "attendance":
        result = _attendance_percentage(school_id)
        source_col = "attendance"

    elif qt == "at_risk":
        low_att  = _low_attendance_students(school_id)
        marks_at = _marks_analysis(school_id).get("at_risk_students", {})
        result   = {
            "low_attendance_students": low_att,
            "failing_3plus_subjects":  marks_at,
        }
        source_col = "attendance + marks"

    elif qt == "fees":
        defaulters = _fee_defaulters(school_id)
        fees_all   = _get_collection(school_id, "fees")
        total_due  = 0.0
        total_paid = 0.0
        for f in fees_all:
            try:
                total_due  += float(f.get("amount", 0))
                total_paid += float(f.get("paid_amount", 0))
            except (ValueError, TypeError):
                pass

        # Double-verify totals
        total_due2  = sum(float(f.get("amount", 0))      for f in fees_all if str(f.get("amount", "")).replace(".", "").isdigit())
        total_paid2 = sum(float(f.get("paid_amount", 0)) for f in fees_all if str(f.get("paid_amount", "")).replace(".", "").isdigit())

        if abs(total_due - total_due2) > 0.01 or abs(total_paid - total_paid2) > 0.01:
            return json.dumps({
                "error": "Double-verification of fee totals failed. Please check Firebase console.",
                "confidence": 30,
            })

        result = {
            "total_fees_due":     round(total_due, 2),
            "total_fees_paid":    round(total_paid, 2),
            "total_fees_pending": round(total_due - total_paid, 2),
            "defaulters_count":   len(defaulters),
            "defaulters":         defaulters[:10],   # first 10
            "verified":           True,
        }
        source_col = "fees"

    elif qt == "marks":
        result     = _marks_analysis(school_id)
        source_col = "marks"

    elif qt == "students":
        students   = _get_collection(school_id, "students")
        result     = {"total_students": len(students), "students": students[:20]}
        source_col = "students"

    elif qt == "staff":
        staff      = _get_collection(school_id, "staff")
        result     = {"total_staff": len(staff), "staff": staff}
        source_col = "staff"

    elif qt == "complaints":
        complaints = _get_collection(school_id, "complaints")
        overdue    = []
        cutoff     = (datetime.now() - timedelta(days=7)).isoformat()
        for c in complaints:
            if c.get("status", "").lower() not in ("resolved", "closed"):
                if str(c.get("date", "")) < cutoff:
                    overdue.append(c)
        result = {
            "total_complaints":   len(complaints),
            "unresolved":         [c for c in complaints if c.get("status", "").lower() not in ("resolved", "closed")],
            "overdue_7plus_days": overdue,
        }
        source_col = "complaints"

    elif qt == "sms_logs":
        logs   = _get_collection(school_id, "sms_logs")
        result = {"total_sms_sent": len(logs), "recent_logs": logs[-10:]}
        source_col = "sms_logs"

    else:
        # general — return school overview
        students   = _get_collection(school_id, "students")
        staff      = _get_collection(school_id, "staff")
        complaints = _get_collection(school_id, "complaints")
        att_data   = _attendance_percentage(school_id)
        result = {
            "school_name":        school_name,
            "total_students":     len(students),
            "total_staff":        len(staff),
            "open_complaints":    len([c for c in complaints if c.get("status", "").lower() not in ("resolved", "closed")]),
            "attendance_summary": att_data,
        }
        source_col = "students + staff + attendance + complaints"

    if confidence < CONFIDENCE_MIN_THRESHOLD:
        confidence_note = "⚠️  I am not confident about this. Please verify manually."
    else:
        confidence_note = ""

    return json.dumps({
        "question":         question,
        "school":           school_name,
        "answer":           result,
        "confidence":       confidence,
        "confidence_note":  confidence_note,
        "source": (
            f"Firebase schools/{school_id}/{source_col} collection. "
            f"As of: {timestamp}"
        ),
        "timestamp":        timestamp,
        "feedback_prompt":  "[✅ Correct] [❌ Wrong] [⚠️ Partial]",
    }, ensure_ascii=False, indent=2, default=str)
