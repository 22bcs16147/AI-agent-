"""
app.py — MyChalkPad Master Agent — Streamlit Web Interface
───────────────────────────────────────────────────────────
Full chat UI with file upload, quick actions, school selector,
sidebar stats, and feedback system. Hindi language support.
"""

import io
import json
import os
import threading
import uuid
from datetime import datetime

import streamlit as st
from apscheduler.schedulers.background import BackgroundScheduler

from config.settings import (
    BRAND_NAVY, BRAND_ORANGE, SCHOOL_ID, OUTPUT_DIR,
    MORNING_REPORT_HOUR, MORNING_REPORT_MINUTE,
    EOD_REPORT_HOUR, EOD_REPORT_MINUTE,
    WEEKLY_REPORT_DAY, WEEKLY_REPORT_HOUR, WEEKLY_REPORT_MINUTE,
)
from master_agent import run_task, run_morning_report, run_eod_report, run_weekly_report, save_feedback

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── Page Config ───────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="MyChalkPad AI Agent",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────

st.markdown(f"""
<style>
    /* Brand colors */
    :root {{
        --navy:  {BRAND_NAVY};
        --orange:{BRAND_ORANGE};
    }}

    /* Top header bar */
    .main-header {{
        background: linear-gradient(135deg, {BRAND_NAVY}, #2a5298);
        padding: 1.2rem 2rem;
        border-radius: 12px;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 1rem;
    }}
    .main-header h1 {{
        color: white;
        margin: 0;
        font-size: 1.8rem;
        font-weight: 700;
    }}
    .main-header p {{
        color: #cce0ff;
        margin: 0;
        font-size: 0.9rem;
    }}

    /* Quick action buttons */
    .stButton > button {{
        background: {BRAND_NAVY};
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.5rem 1.2rem;
        font-weight: 600;
        transition: background 0.2s;
    }}
    .stButton > button:hover {{
        background: {BRAND_ORANGE};
        color: white;
    }}

    /* Chat messages */
    .user-msg {{
        background: {BRAND_NAVY};
        color: white;
        padding: 0.8rem 1.2rem;
        border-radius: 12px 12px 2px 12px;
        margin: 0.5rem 0 0.5rem 2rem;
        font-size: 0.95rem;
    }}
    .agent-msg {{
        background: #f0f4ff;
        border-left: 4px solid {BRAND_ORANGE};
        padding: 0.8rem 1.2rem;
        border-radius: 2px 12px 12px 12px;
        margin: 0.5rem 2rem 0.5rem 0;
        font-size: 0.95rem;
    }}
    .confidence-badge {{
        display: inline-block;
        background: {BRAND_ORANGE};
        color: white;
        border-radius: 20px;
        padding: 2px 10px;
        font-size: 0.8rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
    }}
    .feedback-row {{
        margin-top: 0.5rem;
        font-size: 0.85rem;
        color: #666;
    }}

    /* Sidebar */
    .sidebar-stat {{
        background: white;
        border-radius: 8px;
        padding: 0.7rem 1rem;
        margin: 0.5rem 0;
        border-left: 4px solid {BRAND_ORANGE};
        font-size: 0.9rem;
    }}

    /* Hide Streamlit default elements */
    #MainMenu {{visibility: hidden;}}
    footer    {{visibility: hidden;}}
</style>
""", unsafe_allow_html=True)


# ── Session State Initialisation ──────────────────────────────────────────────

def _init_state():
    defaults = {
        "messages":       [],       # [{role, content, response_id, timestamp}]
        "school_id":      SCHOOL_ID,
        "csv_content":    None,
        "csv_type":       None,
        "sms_count":      0,
        "csv_count":      0,
        "lead_count":     0,
        "scheduler_started": False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()


# ── Scheduler ─────────────────────────────────────────────────────────────────

def _start_scheduler():
    """Start APScheduler background jobs once per app lifetime."""
    if st.session_state.scheduler_started:
        return

    scheduler = BackgroundScheduler()

    # Daily 8 AM morning report
    scheduler.add_job(
        lambda: _save_scheduled_report("morning", run_morning_report()),
        "cron", hour=MORNING_REPORT_HOUR, minute=MORNING_REPORT_MINUTE,
    )
    # Daily 6 PM EOD report
    scheduler.add_job(
        lambda: _save_scheduled_report("eod", run_eod_report()),
        "cron", hour=EOD_REPORT_HOUR, minute=EOD_REPORT_MINUTE,
    )
    # Weekly Monday 9 AM report
    scheduler.add_job(
        lambda: _save_scheduled_report("weekly", run_weekly_report()),
        "cron", day_of_week=WEEKLY_REPORT_DAY,
        hour=WEEKLY_REPORT_HOUR, minute=WEEKLY_REPORT_MINUTE,
    )

    try:
        scheduler.start()
        st.session_state.scheduler_started = True
    except Exception:
        pass   # scheduler already running (hot-reload)


def _save_scheduled_report(report_type: str, content: str):
    """Save a scheduled report to the output directory."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    fname = os.path.join(OUTPUT_DIR, f"{report_type}_{datetime.now().strftime('%Y%m%d_%H%M')}.txt")
    with open(fname, "w") as f:
        f.write(content)


# ── Language Detection ────────────────────────────────────────────────────────

def _is_hindi(text: str) -> bool:
    """Returns True if the text contains Devanagari characters."""
    return any("\u0900" <= c <= "\u097F" for c in text)


# ── Confidence Extraction ─────────────────────────────────────────────────────

def _extract_confidence(text: str) -> int:
    """Extract confidence percentage from agent response text."""
    import re
    match = re.search(r"confidence[:\s]+(\d{1,3})%", text, re.IGNORECASE)
    if match:
        return int(match.group(1))
    # Try JSON responses
    try:
        data = json.loads(text)
        if "confidence" in data:
            return int(data["confidence"])
    except Exception:
        pass
    return 90   # default


# ── Chat Functions ────────────────────────────────────────────────────────────

def _add_user_message(content: str):
    st.session_state.messages.append({
        "role":        "user",
        "content":     content,
        "timestamp":   datetime.now().strftime("%H:%M"),
        "response_id": str(uuid.uuid4()),
    })


def _add_agent_message(content: str):
    confidence = _extract_confidence(content)

    # Try to pretty-print JSON responses
    display_content = content
    try:
        parsed = json.loads(content)
        if isinstance(parsed, dict):
            # Extract the most useful parts
            parts = []
            if "summary" in parsed:
                parts.append(parsed["summary"])
            if "answer" in parsed:
                ans = parsed["answer"]
                parts.append(json.dumps(ans, indent=2, ensure_ascii=False, default=str) if isinstance(ans, dict) else str(ans))
            if "content" in parsed:
                parts.append(str(parsed["content"]))
            if "leads" in parsed:
                parts.append(f"Found {len(parsed['leads'])} leads.")
            if "error" in parsed:
                parts.append(f"⚠️ Error: {parsed['error']}")
            if "source" in parsed:
                parts.append(f"\n📌 Source: {parsed['source']}")
            display_content = "\n\n".join(parts) if parts else content
    except Exception:
        pass

    if confidence < 80:
        display_content += "\n\n⚠️  I am not confident about this. Please verify manually."

    rid = str(uuid.uuid4())
    st.session_state.messages.append({
        "role":        "agent",
        "content":     display_content,
        "raw_content": content,
        "confidence":  confidence,
        "timestamp":   datetime.now().strftime("%H:%M"),
        "response_id": rid,
    })
    return rid


def _run_agent(user_input: str, csv_content=None, csv_type=None):
    """Run the agent in a thread-safe way and store the response."""
    with st.spinner("🤖 Agent thinking..."):
        response = run_task(
            user_input=user_input,
            school_id=st.session_state.school_id,
            csv_content=csv_content,
            csv_type=csv_type,
        )
    _add_agent_message(response)

    # Update counters
    if csv_content:
        st.session_state.csv_count += 1
    if "sms" in user_input.lower() or "send" in user_input.lower():
        st.session_state.sms_count += 1
    if "lead" in user_input.lower() or "find school" in user_input.lower():
        st.session_state.lead_count += 1


# ── Sidebar ───────────────────────────────────────────────────────────────────

def _render_sidebar():
    with st.sidebar:
        st.markdown(f"""
        <div style="background:{BRAND_NAVY};padding:1rem;border-radius:10px;text-align:center;margin-bottom:1rem;">
            <h2 style="color:white;margin:0;font-size:1.4rem;">🎓 MyChalkPad</h2>
            <p style="color:#aac4ff;margin:0;font-size:0.8rem;">AI Operations Agent</p>
        </div>
        """, unsafe_allow_html=True)

        # School selector
        st.subheader("🏫 School")
        school_options = {
            "demo_school_001": "Sunrise Public School (Demo)",
            "custom":          "Enter custom school ID...",
        }
        selected = st.selectbox("Select school", list(school_options.values()))
        if selected == "Enter custom school ID...":
            custom_id = st.text_input("School ID", value=st.session_state.school_id)
            if custom_id:
                st.session_state.school_id = custom_id
        else:
            for k, v in school_options.items():
                if v == selected:
                    st.session_state.school_id = k

        st.markdown(f"**Active school:** `{st.session_state.school_id}`")

        # Date range picker
        st.subheader("📅 Date Range")
        col1, col2 = st.columns(2)
        with col1:
            st.date_input("From", key="date_from")
        with col2:
            st.date_input("To",   key="date_to")

        # Quick stats
        st.subheader("📊 Today's Stats")
        st.markdown(f"""
        <div class="sidebar-stat">📱 SMS sent today: <b>{st.session_state.sms_count}</b></div>
        <div class="sidebar-stat">📁 CSVs processed: <b>{st.session_state.csv_count}</b></div>
        <div class="sidebar-stat">🎯 Leads found: <b>{st.session_state.lead_count}</b></div>
        <div class="sidebar-stat">💬 Messages: <b>{len(st.session_state.messages)}</b></div>
        """, unsafe_allow_html=True)

        # Scheduled reports
        st.subheader("⏰ Scheduled Reports")
        st.caption(f"Morning report: 8:00 AM daily")
        st.caption(f"EOD report: 6:00 PM daily")
        st.caption(f"Weekly report: Monday 9:00 AM")

        # Manual triggers
        st.subheader("▶️ Run Reports Now")
        if st.button("📊 Morning Report"):
            with st.spinner("Generating morning report..."):
                report = run_morning_report()
            _add_user_message("Generate morning report")
            _add_agent_message(report)
            st.rerun()

        if st.button("📈 Weekly Report"):
            with st.spinner("Generating weekly report..."):
                report = run_weekly_report()
            _add_user_message("Generate weekly report")
            _add_agent_message(report)
            st.rerun()

        # Clear chat
        if st.button("🗑️ Clear Chat"):
            st.session_state.messages = []
            st.rerun()

        # Language note
        st.markdown("---")
        st.caption("💬 हिंदी में भी लिख सकते हैं")
        st.caption("You can also type in Hindi!")


# ── Message Renderer ──────────────────────────────────────────────────────────

def _render_messages():
    for msg in st.session_state.messages:
        if msg["role"] == "user":
            st.markdown(f"""
            <div class="user-msg">
                <strong>You</strong> <span style="opacity:0.6;font-size:0.8rem">{msg['timestamp']}</span><br>
                {msg['content']}
            </div>
            """, unsafe_allow_html=True)
        else:
            conf  = msg.get("confidence", 90)
            badge_color = BRAND_ORANGE if conf >= 80 else "#e74c3c"
            st.markdown(f"""
            <div class="agent-msg">
                <span class="confidence-badge" style="background:{badge_color};">
                    Confidence: {conf}%
                </span>
                <strong>🤖 MyChalkPad Agent</strong>
                <span style="opacity:0.6;font-size:0.8rem"> {msg['timestamp']}</span><br>
                <pre style="white-space:pre-wrap;font-family:inherit;margin-top:0.5rem">{msg['content']}</pre>
            </div>
            """, unsafe_allow_html=True)

            # Feedback buttons
            col1, col2, col3, col4 = st.columns([1, 1, 1, 5])
            rid = msg.get("response_id", "")
            with col1:
                if st.button("✅", key=f"ok_{rid}", help="Correct"):
                    save_feedback(rid, "correct", msg.get("raw_content", msg["content"]))
                    st.toast("Thanks for your feedback! ✅")
            with col2:
                if st.button("❌", key=f"wrong_{rid}", help="Wrong"):
                    save_feedback(rid, "wrong", msg.get("raw_content", msg["content"]))
                    st.toast("Feedback saved. We'll improve! ❌")
            with col3:
                if st.button("⚠️", key=f"partial_{rid}", help="Partially correct"):
                    save_feedback(rid, "partial", msg.get("raw_content", msg["content"]))
                    st.toast("Feedback saved. ⚠️")

            # Download button for this response
            raw = msg.get("raw_content", msg["content"])
            st.download_button(
                "⬇️ Download",
                data=raw,
                file_name=f"mychalkpad_response_{rid[:8]}.txt",
                mime="text/plain",
                key=f"dl_{rid}",
            )


# ── Main Layout ───────────────────────────────────────────────────────────────

def main():
    _start_scheduler()
    _render_sidebar()

    # Header
    st.markdown(f"""
    <div class="main-header">
        <div>
            <h1>🎓 MyChalkPad AI Agent</h1>
            <p>School ERP Intelligence — CSV Processing · Analytics · SMS · Sales · Marketing</p>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ── Quick Action Buttons ──────────────────────────────────────────────────
    st.markdown("**Quick Actions:**")
    qa_cols = st.columns(5)
    quick_actions = [
        ("📊 Daily Report",     "Generate the morning analytics report for all schools"),
        ("📁 Process CSV",      "I want to upload and process a CSV file"),
        ("📱 Send SMS",         "Send fee reminder SMS to parents with overdue payments"),
        ("🎯 Find Leads",       "Find school leads in Pune city for MyChalkPad sales"),
        ("📢 Create Content",   "Create an Instagram post about MyChalkPad attendance feature"),
    ]
    for col, (label, prompt) in zip(qa_cols, quick_actions):
        with col:
            if st.button(label):
                _add_user_message(prompt)
                _run_agent(prompt)
                st.rerun()

    st.markdown("---")

    # ── CSV Upload ────────────────────────────────────────────────────────────
    with st.expander("📁 Upload CSV File", expanded=False):
        col1, col2 = st.columns([3, 1])
        with col1:
            uploaded_file = st.file_uploader(
                "Upload school CSV",
                type=["csv"],
                help="Upload students, attendance, marks, fees, or staff CSV",
            )
        with col2:
            csv_type_select = st.selectbox(
                "CSV Type",
                ["students", "attendance", "marks", "fees", "staff"],
            )

        if uploaded_file is not None:
            csv_text = uploaded_file.read().decode("utf-8", errors="replace")
            st.session_state.csv_content = csv_text
            st.session_state.csv_type    = csv_type_select
            st.success(f"✅ {uploaded_file.name} uploaded ({len(csv_text)} chars)")

            if st.button("🔄 Process CSV Now"):
                prompt = f"Process and validate this {csv_type_select} CSV file for school {st.session_state.school_id}"
                _add_user_message(prompt)
                _run_agent(
                    prompt,
                    csv_content=st.session_state.csv_content,
                    csv_type=st.session_state.csv_type,
                )
                st.rerun()

    # ── CSV Templates Download ────────────────────────────────────────────────
    with st.expander("📋 Download CSV Templates", expanded=False):
        template_cols = st.columns(5)
        templates = {
            "students":   "name,class,section,roll_number,parent_phone,address,admission_date,gender,date_of_birth\n",
            "attendance": "student_id,date,status,class,section,marked_by\n",
            "marks":      "student_id,subject,exam_type,marks,max_marks,class,section\n",
            "fees":       "student_id,student_name,amount,paid_amount,due_date,status,payment_date,payment_mode,receipt_number\n",
            "staff":      "name,role,phone,subject,class_assigned,section_assigned,joining_date\n",
        }
        for col, (tname, tdata) in zip(template_cols, templates.items()):
            with col:
                st.download_button(
                    f"⬇️ {tname.capitalize()}",
                    data=tdata,
                    file_name=f"{tname}_template.csv",
                    mime="text/csv",
                )

    # ── Chat Messages ─────────────────────────────────────────────────────────
    _render_messages()

    # ── Chat Input ────────────────────────────────────────────────────────────
    st.markdown("---")

    with st.form("chat_form", clear_on_submit=True):
        col_input, col_btn = st.columns([8, 1])
        with col_input:
            user_text = st.text_input(
                "Message",
                placeholder="Ask anything about your schools... or type in Hindi | हिंदी में लिखें...",
                label_visibility="collapsed",
            )
        with col_btn:
            submitted = st.form_submit_button("Send ➤")

    if submitted and user_text.strip():
        # Hindi support: prefix instruction
        if _is_hindi(user_text):
            user_text_for_agent = f"[User is writing in Hindi. Please respond in Hindi.] {user_text}"
        else:
            user_text_for_agent = user_text

        _add_user_message(user_text)
        _run_agent(
            user_text_for_agent,
            csv_content=st.session_state.csv_content,
            csv_type=st.session_state.csv_type,
        )
        # Clear CSV after processing
        st.session_state.csv_content = None
        st.session_state.csv_type    = None
        st.rerun()

    # ── Footer ────────────────────────────────────────────────────────────────
    st.markdown(f"""
    <div style="text-align:center;margin-top:2rem;padding:1rem;
                background:{BRAND_NAVY};border-radius:10px;color:white;font-size:0.8rem;">
        🎓 MyChalkPad AI Agent &nbsp;|&nbsp;
        Powered by Groq llama-3.3-70b &nbsp;|&nbsp;
        <a href="https://mychalkpad.com" style="color:{BRAND_ORANGE};">mychalkpad.com</a>
    </div>
    """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()
