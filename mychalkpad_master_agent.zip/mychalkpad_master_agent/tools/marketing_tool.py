"""
tools/marketing_tool.py — Brain 6: Marketing Brain
────────────────────────────────────────────────────
Generates Instagram posts, reel scripts, LinkedIn posts,
WhatsApp broadcasts, cold email templates, and content calendars
— all about MyChalkPad features.
"""

import json
from datetime import datetime, timedelta
from typing import Optional

from crewai.tools import tool

# ── Content Templates ─────────────────────────────────────────────────────────

INSTAGRAM_CAPTIONS = {
    "attendance": """📱 No more registers. No more confusion.

MyChalkPad marks attendance in seconds — and sends instant SMS to parents! 📲

✅ Mark attendance on mobile
✅ Automatic absent alerts to parents  
✅ Monthly reports auto-generated
✅ Works offline too!

50+ schools already switched. Will yours be next? 🏫

👉 Get your FREE 30-day trial — link in bio!

#EdTech #SchoolManagement #MyChalkPad #IndianSchools #DigitalSchool #SchoolERP #AttendanceManagement #EducationTechnology #SmartSchool #SchoolAdmin""",

    "fees": """💰 Chasing fee payments manually? There's a better way.

MyChalkPad automates your entire fee management! 🎯

✅ Send reminders with one click
✅ Track paid/unpaid/partial instantly
✅ Digital receipts for every payment
✅ Parents pay online — no more queues!

Save 3 hours every week. Start FREE today!

#FeeManagement #SchoolERP #MyChalkPad #EdTech #SchoolAdmin #DigitalSchool #IndianSchools #PaperlessSchool""",

    "marks": """📊 Exam results in parents' hands in 60 seconds!

With MyChalkPad, report cards are automatic 🚀

✅ Enter marks once — all calculations done
✅ Class rankings generated instantly
✅ SMS sent to parents automatically
✅ Compare performance over terms

Try it FREE → link in bio 👆

#ExamResults #ReportCard #SchoolManagement #MyChalkPad #EdTech #MarksManagement #IndianEducation""",

    "general": """🏫 Managing a school shouldn't feel like managing a crisis.

Meet MyChalkPad — India's simplest School ERP for 
attendance, fees, marks & parent communication.

All in one app. Starting at ₹0/month for the trial! 🎉

50 schools. 10,000+ students. Growing every week.

Ready to join? DM us or visit mychalkpad.com

#MyChalkPad #SchoolERP #EdTech #IndianSchools #SchoolManagement #DigitalTransformation #Education""",
}

LINKEDIN_POSTS = {
    "growth": """We started MyChalkPad with 3 people and 1 school.

Today, we're powering 50+ schools across India.

Here's what we learned about selling EdTech to school principals:

1. They don't buy software — they buy time savings
2. ROI must be visible in 30 days or you lose them
3. The secretary/admin staff are your actual champions
4. WhatsApp demos convert 3x better than email
5. Free trials with setup support win every time

The Indian EdTech market for school management is massive and massively underserved.

We're just getting started.

If you're a school principal reading this — DM me for a free demo.

#EdTech #StartupIndia #SchoolManagement #MyChalkPad #B2BSaaS #IndianStartup""",

    "feature": """Sent 50,000 SMS messages to parents last month.

Cost? Practically zero.
Time taken? About 3 minutes per school.

This is what MyChalkPad does for schools every day.

One principal told me: "I used to spend 2 hours calling parents about fees.
Now I click one button and it's done."

That's the product. That's the mission.

Build tools that give people their time back.

#ProductBuilding #EdTech #MyChalkPad #SMSMarketing #SchoolManagement""",
}


def _instagram_post(topic: str, custom_prompt: Optional[str] = None) -> dict:
    topic_key = topic.lower() if topic.lower() in INSTAGRAM_CAPTIONS else "general"
    caption   = custom_prompt if custom_prompt else INSTAGRAM_CAPTIONS[topic_key]
    return {
        "platform": "Instagram",
        "caption":  caption,
        "hashtag_count": caption.count("#"),
        "character_count": len(caption),
        "recommended_image": f"Visual showing MyChalkPad {topic} feature on mobile screen — navy/orange brand colors",
        "best_post_times": ["8:00 AM", "12:30 PM", "7:00 PM"],
    }


def _reel_script(topic: str) -> dict:
    """Generate a scene-by-scene Instagram Reel script."""
    scripts = {
        "attendance": {
            "duration": "30 seconds",
            "hook": "POV: You're a teacher still calling names in 2026 📋",
            "scenes": [
                {"scene": 1, "duration": "3s", "visual": "Teacher with paper register, frustrated look", "audio": "Sound of pen scratching paper"},
                {"scene": 2, "duration": "3s", "visual": "Phone notification — MyChalkPad attendance screen", "audio": "Phone notification sound"},
                {"scene": 3, "duration": "5s", "visual": "Screen recording: Mark Present/Absent in one tap", "audio": "Upbeat background music starts"},
                {"scene": 4, "duration": "5s", "visual": "Animation: SMS flying to parent's phone", "audio": "'Attendance marked. SMS sent to parents!'"},
                {"scene": 5, "duration": "5s", "visual": "Principal dashboard showing attendance % across classes", "audio": "Voiceover: 'Full school attendance in 60 seconds'"},
                {"scene": 6, "duration": "4s", "visual": "Happy teacher walking away from computer", "audio": "Relaxing music"},
                {"scene": 7, "duration": "5s", "visual": "MyChalkPad logo + 'Try FREE' CTA screen", "audio": "Voiceover: 'Free trial — link in bio'"},
            ],
            "caption": INSTAGRAM_CAPTIONS["attendance"],
            "music_suggestion": "Upbeat corporate / motivational",
        },
        "fees": {
            "duration": "30 seconds",
            "hook": "When the accountant says 'fee reminder' for the 10th time this week 😭",
            "scenes": [
                {"scene": 1, "duration": "3s", "visual": "Accountant on phone, stack of papers on desk", "audio": "Busy office noise"},
                {"scene": 2, "duration": "3s", "visual": "MyChalkPad Fees screen — red unpaid list", "audio": "Notification sound"},
                {"scene": 3, "duration": "5s", "visual": "Click 'Send Reminder to All' button", "audio": "Click sound"},
                {"scene": 4, "duration": "5s", "visual": "Animation: hundreds of SMS sent simultaneously", "audio": "Rapid notification sounds"},
                {"scene": 5, "duration": "5s", "visual": "Payments rolling in — status changing to 'Paid'", "audio": "Cash register sounds"},
                {"scene": 6, "duration": "4s", "visual": "Accountant relaxed, drinking chai ☕", "audio": "Chill music"},
                {"scene": 7, "duration": "5s", "visual": "MyChalkPad logo + website CTA", "audio": "Voiceover: 'Automate fee collection today'"},
            ],
            "caption": INSTAGRAM_CAPTIONS["fees"],
            "music_suggestion": "Trending audio or comedic sound effect",
        },
    }
    key = topic.lower() if topic.lower() in scripts else "attendance"
    return scripts[key]


def _whatsapp_broadcast(message_type: str) -> dict:
    messages = {
        "demo_offer": (
            "🎓 *MyChalkPad — Free Demo for Your School*\n\n"
            "Hello Principal/Admin,\n\n"
            "We help schools manage:\n"
            "✅ Attendance with parent SMS\n"
            "✅ Fee collection & reminders\n"
            "✅ Marks & report cards\n"
            "✅ Parent communication app\n\n"
            "📱 *FREE 30-day trial. Full setup support.*\n\n"
            "Reply *DEMO* to book a 20-min call!\n\n"
            "— Team MyChalkPad\n"
            "www.mychalkpad.com"
        ),
        "feature_update": (
            "🚀 *MyChalkPad New Feature Alert!*\n\n"
            "📊 Bulk marks upload via CSV now live!\n\n"
            "Upload 500 student marks in under 60 seconds.\n"
            "Auto-calculates rankings, averages & subject-wise analysis.\n\n"
            "👉 Update your app or visit the portal to try it now!\n\n"
            "Questions? Reply to this message.\n"
            "— Team MyChalkPad"
        ),
        "seasonal": (
            "🌸 *New Academic Year — New Beginnings!*\n\n"
            "Is your school ready for 2026-27?\n\n"
            "Migrate your student data to MyChalkPad in one day.\n"
            "We handle everything — data import, staff training, setup.\n\n"
            "*Special new-year pricing available for March sign-ups!*\n\n"
            "Reply *YES* to know more.\n"
            "— Team MyChalkPad"
        ),
    }
    mt = message_type.lower() if message_type.lower() in messages else "demo_offer"
    return {
        "platform": "WhatsApp Broadcast",
        "message":  messages[mt],
        "char_count": len(messages[mt]),
        "estimated_reach": "All contacts in your broadcast list",
    }


def _content_calendar(weeks: int = 4) -> list[dict]:
    """Generate a content calendar for the next N weeks."""
    calendar   = []
    today      = datetime.now()
    post_types = [
        ("Monday",    "Instagram",  "Feature highlight — attendance"),
        ("Wednesday", "LinkedIn",   "Growth/founder story"),
        ("Thursday",  "Instagram",  "Reel — fee automation"),
        ("Friday",    "WhatsApp",   "Weekend demo offer broadcast"),
        ("Saturday",  "Instagram",  "Customer success story / testimonial"),
    ]
    for week in range(weeks):
        week_start = today + timedelta(weeks=week)
        for day_name, platform, content_type in post_types:
            # Find the next occurrence of day_name
            days_map = {"Monday": 0, "Tuesday": 1, "Wednesday": 2, "Thursday": 3,
                        "Friday": 4, "Saturday": 5, "Sunday": 6}
            delta = (days_map[day_name] - week_start.weekday()) % 7
            post_date = (week_start + timedelta(days=delta)).strftime("%Y-%m-%d")
            calendar.append({
                "date":         post_date,
                "day":          day_name,
                "platform":     platform,
                "content_type": content_type,
                "status":       "scheduled",
            })

    return sorted(calendar, key=lambda x: x["date"])


def _cold_email_template(target: str = "principal") -> dict:
    templates = {
        "principal": {
            "subject": "Cut your school's admin workload by 70% — Free Demo",
            "body": (
                "Dear Principal,\n\n"
                "I'll be direct: managing a school in 2026 with paper registers and "
                "WhatsApp groups is costing you 3-4 hours daily.\n\n"
                "MyChalkPad replaces all of that with one simple app.\n\n"
                "📱 Attendance → SMS to parents in 60 seconds\n"
                "💰 Fee reminders → sent to 200 parents in 1 click\n"
                "📊 Report cards → generated automatically after exams\n\n"
                "We've helped 50+ schools across India. Setup takes 1 day.\n"
                "Trial is completely FREE — no credit card, no commitment.\n\n"
                "Can I show you a 20-minute demo this week?\n\n"
                "Best,\n[Your Name]\nMyChalkPad\nphone: +91-XXXXXXXXXX"
            ),
        },
        "accountant": {
            "subject": "Automate your school's fee collection — MyChalkPad",
            "body": (
                "Dear Sir/Madam,\n\n"
                "Are you still manually calling parents about overdue fees?\n\n"
                "MyChalkPad's fee module lets you:\n"
                "✅ See all pending fees at a glance\n"
                "✅ Send bulk SMS reminders in one click\n"
                "✅ Accept online payments\n"
                "✅ Auto-generate receipts\n\n"
                "No more chasing. No more manual tracking.\n\n"
                "30-day FREE trial available. Reply to book a call.\n\n"
                "Thanks,\nMyChalkPad Team"
            ),
        },
    }
    t = target.lower() if target.lower() in templates else "principal"
    return templates[t]


# ── Main Tool ─────────────────────────────────────────────────────────────────

@tool("Marketing Brain")
def create_content(
    content_type: str,
    topic: str = "general",
    target_audience: str = "principal",
    custom_prompt: Optional[str] = None,
) -> str:
    """
    Generate marketing content for MyChalkPad across all channels.

    Args:
        content_type    : instagram / reel / linkedin / whatsapp / cold_email /
                          content_calendar
        topic           : attendance / fees / marks / general (used for instagram/reel)
        target_audience : principal / accountant / teacher (used for cold_email)
        custom_prompt   : Optional custom override for caption or message.

    Returns:
        JSON string with generated content, confidence, feedback prompt.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ct = content_type.strip().lower()

    if ct == "instagram":
        content = _instagram_post(topic, custom_prompt)

    elif ct == "reel":
        content = _reel_script(topic)

    elif ct == "linkedin":
        lk = topic.lower() if topic.lower() in LINKEDIN_POSTS else "growth"
        content = {
            "platform": "LinkedIn",
            "post":     LINKEDIN_POSTS[lk],
            "char_count": len(LINKEDIN_POSTS[lk]),
            "best_time": "Tuesday–Thursday, 9 AM or 5 PM",
        }

    elif ct == "whatsapp":
        content = _whatsapp_broadcast(topic)

    elif ct == "cold_email":
        content = _cold_email_template(target_audience)
        content["platform"] = "Email"

    elif ct == "content_calendar":
        content = {
            "platform": "All channels",
            "calendar": _content_calendar(weeks=4),
            "total_posts": None,
        }
        content["total_posts"] = len(content["calendar"])

    else:
        return json.dumps({
            "error": (
                f"Unknown content_type '{content_type}'. "
                "Use: instagram / reel / linkedin / whatsapp / cold_email / content_calendar"
            ),
            "confidence": 0,
        })

    return json.dumps({
        "content_type":    content_type,
        "topic":           topic,
        "content":         content,
        "confidence":      95,
        "source":          f"MyChalkPad Marketing Brain. Generated at: {timestamp}",
        "timestamp":       timestamp,
        "feedback_prompt": "[✅ Correct] [❌ Wrong] [⚠️ Partial]",
    }, ensure_ascii=False, indent=2)
