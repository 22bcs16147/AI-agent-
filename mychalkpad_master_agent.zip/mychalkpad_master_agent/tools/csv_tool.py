"""
tools/csv_tool.py — Brain 1: CSV Processing Brain
──────────────────────────────────────────────────
Validates, auto-fixes, and scores CSV files submitted by schools.
Follows the exact column specs from settings.py / Part 3 of the brief.
"""

import io
import re
import json
import hashlib
from datetime import datetime, date
from typing import Optional

import pandas as pd
from crewai.tools import tool

from config.settings import (
    CSV_COLUMNS, APPROVED_SUBJECTS, VALID_GENDERS,
    VALID_STATUSES, VALID_FEE_STATUS, VALID_PAY_MODES,
    VALID_EXAM_TYPES, VALID_ROLES, CSV_ERROR_REJECT_THRESHOLD,
    CSV_MIN_QUALITY_SCORE,
)

# ── Helpers ───────────────────────────────────────────────────────────────────

def _normalize_date(val: str) -> Optional[str]:
    """
    Try multiple date formats and return YYYY-MM-DD.
    Returns None if the value cannot be parsed.
    """
    if not val or str(val).strip() in ("", "nan", "NaT"):
        return None
    val = str(val).strip()
    formats = [
        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y",
        "%m/%d/%Y", "%d.%m.%Y", "%Y/%m/%d",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(val, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


def _normalize_name(val: str) -> str:
    """Title-case a name: 'RAHUL SHARMA' → 'Rahul Sharma'."""
    return " ".join(w.capitalize() for w in str(val).strip().split())


def _normalize_phone(val: str) -> str:
    """Strip non-digits, remove leading +91 / 0, keep last 10 digits."""
    digits = re.sub(r"\D", "", str(val))
    if digits.startswith("91") and len(digits) == 12:
        digits = digits[2:]
    elif digits.startswith("0") and len(digits) == 11:
        digits = digits[1:]
    return digits


def _normalize_section(val: str) -> str:
    """
    'section a', 'Section A', 'sec-A' → 'A'.
    Keeps only the uppercase letter.
    """
    val = str(val).strip()
    match = re.search(r"[A-Za-z]$", val)
    return match.group(0).upper() if match else val.upper()


def _normalize_class(val: str) -> str:
    """'8th', '8th grade', '  8 ' → '8'."""
    val = str(val).strip()
    match = re.search(r"\d+", val)
    return match.group(0) if match else val


def _row_hash(row: pd.Series) -> str:
    """Create a stable hash of a row to detect duplicates."""
    return hashlib.md5(str(row.values.tolist()).encode()).hexdigest()


# ── Per-type Validators ───────────────────────────────────────────────────────

def _fix_student_row(row: pd.Series, idx: int, errors: list) -> pd.Series:
    row = row.copy()

    # name
    if pd.isna(row.get("name")) or str(row.get("name", "")).strip() == "":
        errors.append({"row": idx + 2, "col": "name", "issue": "Missing name — cannot fix", "fixable": False})
    else:
        row["name"] = _normalize_name(row["name"])

    # class
    row["class"] = _normalize_class(row.get("class", ""))

    # section
    row["section"] = _normalize_section(row.get("section", ""))

    # parent_phone
    phone = _normalize_phone(row.get("parent_phone", ""))
    if len(phone) != 10:
        errors.append({"row": idx + 2, "col": "parent_phone", "issue": f"Invalid phone '{phone}'", "fixable": False})
    else:
        row["parent_phone"] = phone

    # dates
    for dcol in ("admission_date", "date_of_birth"):
        fixed = _normalize_date(row.get(dcol, ""))
        if fixed:
            row[dcol] = fixed
        else:
            errors.append({"row": idx + 2, "col": dcol, "issue": f"Unparseable date '{row.get(dcol)}'", "fixable": False})

    # gender
    gender = str(row.get("gender", "")).strip().lower()
    if gender not in VALID_GENDERS:
        errors.append({"row": idx + 2, "col": "gender", "issue": f"Invalid gender '{gender}' (use male/female)", "fixable": False})
    else:
        row["gender"] = gender

    return row


def _fix_attendance_row(row: pd.Series, idx: int, errors: list) -> pd.Series:
    row = row.copy()

    # status
    status = str(row.get("status", "")).strip().lower()
    if status in ("p", "present", "yes", "1"):
        row["status"] = "present"
    elif status in ("a", "absent", "no", "0"):
        row["status"] = "absent"
    else:
        errors.append({"row": idx + 2, "col": "status", "issue": f"Unknown status '{status}'", "fixable": False})

    # date — no future dates allowed
    fixed_date = _normalize_date(row.get("date", ""))
    if not fixed_date:
        errors.append({"row": idx + 2, "col": "date", "issue": f"Unparseable date '{row.get('date')}'", "fixable": False})
    else:
        if fixed_date > date.today().isoformat():
            errors.append({"row": idx + 2, "col": "date", "issue": f"Future date not allowed: {fixed_date}", "fixable": False})
        else:
            row["date"] = fixed_date

    row["class"]   = _normalize_class(row.get("class", ""))
    row["section"] = _normalize_section(row.get("section", ""))
    return row


def _fix_marks_row(row: pd.Series, idx: int, errors: list) -> pd.Series:
    row = row.copy()

    subject = str(row.get("subject", "")).strip()
    if subject not in APPROVED_SUBJECTS:
        errors.append({"row": idx + 2, "col": "subject",
                       "issue": f"Unknown subject '{subject}'. Must be one of: {', '.join(APPROVED_SUBJECTS)}",
                       "fixable": False})

    exam_type = str(row.get("exam_type", "")).strip().lower()
    if exam_type not in VALID_EXAM_TYPES:
        errors.append({"row": idx + 2, "col": "exam_type",
                       "issue": f"Invalid exam_type '{exam_type}'. Use: midterm/final/unit_test",
                       "fixable": False})
    else:
        row["exam_type"] = exam_type

    marks_val = str(row.get("marks", "")).strip()
    if marks_val not in ("", "nan"):
        try:
            m = float(marks_val)
            if not (0 <= m <= 100):
                errors.append({"row": idx + 2, "col": "marks", "issue": f"Marks {m} out of 0-100 range", "fixable": False})
        except ValueError:
            errors.append({"row": idx + 2, "col": "marks", "issue": f"Marks '{marks_val}' is not a number", "fixable": False})

    row["class"]   = _normalize_class(row.get("class", ""))
    row["section"] = _normalize_section(row.get("section", ""))
    return row


def _fix_fees_row(row: pd.Series, idx: int, errors: list) -> pd.Series:
    row = row.copy()

    for money_col in ("amount", "paid_amount"):
        val = str(row.get(money_col, "")).strip().replace("₹", "").replace(",", "")
        try:
            row[money_col] = float(val)
        except ValueError:
            errors.append({"row": idx + 2, "col": money_col, "issue": f"Non-numeric amount '{val}'", "fixable": False})

    status = str(row.get("status", "")).strip().lower()
    if status not in VALID_FEE_STATUS:
        errors.append({"row": idx + 2, "col": "status",
                       "issue": f"Invalid fee status '{status}'. Use: paid/unpaid/partial",
                       "fixable": False})
    else:
        row["status"] = status

    pay_mode = str(row.get("payment_mode", "")).strip().lower()
    if pay_mode not in VALID_PAY_MODES and pay_mode not in ("", "nan"):
        errors.append({"row": idx + 2, "col": "payment_mode",
                       "issue": f"Invalid payment_mode '{pay_mode}'. Use: cash/online/cheque",
                       "fixable": False})
    else:
        row["payment_mode"] = pay_mode

    for dcol in ("due_date", "payment_date"):
        val = str(row.get(dcol, "")).strip()
        if val and val not in ("nan", ""):
            fixed = _normalize_date(val)
            if fixed:
                row[dcol] = fixed
            else:
                errors.append({"row": idx + 2, "col": dcol, "issue": f"Unparseable date '{val}'", "fixable": False})

    return row


def _fix_staff_row(row: pd.Series, idx: int, errors: list) -> pd.Series:
    row = row.copy()

    row["name"] = _normalize_name(row.get("name", ""))

    role = str(row.get("role", "")).strip().lower()
    if role not in VALID_ROLES:
        errors.append({"row": idx + 2, "col": "role",
                       "issue": f"Invalid role '{role}'. Use: teacher/principal/accountant/admin",
                       "fixable": False})
    else:
        row["role"] = role

    phone = _normalize_phone(row.get("phone", ""))
    if len(phone) != 10:
        errors.append({"row": idx + 2, "col": "phone", "issue": f"Invalid phone '{phone}'", "fixable": False})
    else:
        row["phone"] = phone

    subject = str(row.get("subject", "")).strip()
    if subject and subject not in APPROVED_SUBJECTS:
        errors.append({"row": idx + 2, "col": "subject",
                       "issue": f"Unknown subject '{subject}'",
                       "fixable": False})

    fixed_date = _normalize_date(row.get("joining_date", ""))
    if fixed_date:
        row["joining_date"] = fixed_date
    else:
        errors.append({"row": idx + 2, "col": "joining_date",
                       "issue": f"Unparseable date '{row.get('joining_date')}'",
                       "fixable": False})

    row["class_assigned"]   = _normalize_class(row.get("class_assigned", ""))
    row["section_assigned"] = _normalize_section(row.get("section_assigned", ""))
    return row


# ── Quality Scorer ────────────────────────────────────────────────────────────

def _calculate_quality_score(total_rows: int, error_rows: int, dup_rows: int) -> int:
    """
    Score = 100 - (error_penalty + dup_penalty)
    Error penalty: each bad row = 3 points (max 60)
    Dup penalty: each dup = 1 point (max 20)
    """
    if total_rows == 0:
        return 0
    error_pct  = error_rows / total_rows
    dup_pct    = dup_rows   / total_rows
    score = 100 - int(error_pct * 60) - int(dup_pct * 20)
    return max(0, min(100, score))


# ── Main Tool ─────────────────────────────────────────────────────────────────

@tool("CSV Processing Brain")
def process_csv(csv_content: str, csv_type: str, school_id: str = "unknown") -> str:
    """
    Validates, auto-fixes, deduplicates, and scores a school CSV file.

    Args:
        csv_content: Raw CSV text content.
        csv_type: One of students / attendance / marks / fees / staff.
        school_id: Firebase school document ID (for source citation).

    Returns:
        JSON string with keys:
          - summary
          - quality_score
          - errors (list of unfixable issues)
          - clean_csv (fixed CSV text)
          - confidence
          - source
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    csv_type  = csv_type.strip().lower()

    # ── 1. Detect type ────────────────────────────────────────────────────────
    if csv_type not in CSV_COLUMNS:
        return json.dumps({
            "error": f"Unknown csv_type '{csv_type}'. "
                     f"Use one of: {', '.join(CSV_COLUMNS.keys())}",
            "confidence": 0,
        })

    expected_cols = CSV_COLUMNS[csv_type]

    # ── 2. Parse ──────────────────────────────────────────────────────────────
    try:
        df = pd.read_csv(io.StringIO(csv_content))
    except Exception as exc:
        return json.dumps({
            "error": f"Cannot parse CSV: {exc}",
            "confidence": 0,
        })

    df.columns = [c.strip().lower() for c in df.columns]

    # ── 3. Column check ───────────────────────────────────────────────────────
    missing_cols = [c for c in expected_cols if c not in df.columns]
    if missing_cols:
        return json.dumps({
            "error": f"Missing required columns: {missing_cols}",
            "expected_columns": expected_cols,
            "found_columns": list(df.columns),
            "confidence": 10,
        })

    df = df[expected_cols].copy()   # keep only expected columns, in order
    df = df.applymap(lambda x: str(x).strip() if pd.notna(x) else x)

    original_count = len(df)

    # ── 4. Remove exact duplicates ────────────────────────────────────────────
    hashes    = df.apply(_row_hash, axis=1)
    dup_mask  = hashes.duplicated(keep="first")
    dup_count = dup_mask.sum()
    df        = df[~dup_mask].reset_index(drop=True)

    # ── 5. Row-level fixes ────────────────────────────────────────────────────
    fixers = {
        "students":   _fix_student_row,
        "attendance": _fix_attendance_row,
        "marks":      _fix_marks_row,
        "fees":       _fix_fees_row,
        "staff":      _fix_staff_row,
    }
    fixer = fixers[csv_type]
    all_errors: list = []

    fixed_rows = []
    for idx, row in df.iterrows():
        fixed_row = fixer(row, idx, all_errors)
        fixed_rows.append(fixed_row)

    df_fixed = pd.DataFrame(fixed_rows)

    # ── 6. Count error rows ───────────────────────────────────────────────────
    error_row_nums = {e["row"] for e in all_errors}
    error_row_count = len(error_row_nums)

    # ── 7. Quality score ──────────────────────────────────────────────────────
    quality_score = _calculate_quality_score(original_count, error_row_count, dup_count)

    # ── 8. Reject if too many errors ──────────────────────────────────────────
    error_ratio = error_row_count / max(original_count, 1)
    if error_ratio > CSV_ERROR_REJECT_THRESHOLD:
        return json.dumps({
            "summary": (
                f"CSV quality too low (score: {quality_score}/100). "
                f"Too many errors to auto-fix ({error_row_count}/{original_count} rows). "
                f"Please download our template and resubmit."
            ),
            "quality_score": quality_score,
            "errors": all_errors[:20],
            "clean_csv": None,
            "confidence": 95,
            "source": f"CSV validation — {csv_type} upload for school {school_id}",
            "timestamp": timestamp,
        })

    # ── 9. Convert fixed DF back to CSV text ──────────────────────────────────
    clean_csv_text = df_fixed.to_csv(index=False)

    # ── 10. Confidence ────────────────────────────────────────────────────────
    confidence = min(99, 60 + quality_score // 2)

    summary_lines = [
        f"CSV Type         : {csv_type}",
        f"Original Rows    : {original_count}",
        f"Duplicate Rows   : {dup_count} (removed)",
        f"Rows with Errors : {error_row_count}",
        f"Clean Rows       : {len(df_fixed)}",
        f"Quality Score    : {quality_score}/100",
        f"Auto-fixed       : dates, names, phone numbers, class/section format",
    ]

    if quality_score < 80:
        summary_lines.append(
            "⚠️  I am not confident about this. Please verify manually."
        )

    result = {
        "summary":       "\n".join(summary_lines),
        "quality_score": quality_score,
        "errors":        all_errors,
        "clean_csv":     clean_csv_text,
        "confidence":    confidence,
        "source": (
            f"CSV validation — {csv_type} upload for school {school_id}. "
            f"Records checked: {original_count}. "
            f"As of: {timestamp}"
        ),
        "timestamp": timestamp,
        "feedback_prompt": "[✅ Correct] [❌ Wrong] [⚠️ Partial]",
    }

    return json.dumps(result, ensure_ascii=False, indent=2)
