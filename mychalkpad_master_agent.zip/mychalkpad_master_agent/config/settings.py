"""
config/settings.py
──────────────────
Central configuration for MyChalkPad Master Agent.
Loads all environment variables and defines app-wide constants.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ── LLM Config ───────────────────────────────────────────────────────────────
GROQ_API_KEY        = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL          = "llama-3.3-70b-versatile"

# ── Firebase Config ───────────────────────────────────────────────────────────
FIREBASE_PROJECT_ID   = os.getenv("FIREBASE_PROJECT_ID", "")
FIREBASE_PRIVATE_KEY  = os.getenv("FIREBASE_PRIVATE_KEY", "").replace("\\n", "\n")
FIREBASE_CLIENT_EMAIL = os.getenv("FIREBASE_CLIENT_EMAIL", "")

# ── Third-Party APIs ──────────────────────────────────────────────────────────
SERPER_API_KEY          = os.getenv("SERPER_API_KEY", "")
FAST2SMS_API_KEY        = os.getenv("FAST2SMS_API_KEY", "")
GOOGLE_SHEETS_CREDS     = os.getenv("GOOGLE_SHEETS_CREDENTIALS", "{}")
GOOGLE_SHEET_ID         = os.getenv("GOOGLE_SHEET_ID", "")
TEAM_WHATSAPP_NUMBER    = os.getenv("TEAM_WHATSAPP_NUMBER", "")

# ── App Config ────────────────────────────────────────────────────────────────
APP_ENV     = os.getenv("APP_ENV", "development")
SCHOOL_ID   = os.getenv("SCHOOL_ID", "demo_school_001")

# ── Brand Colors ──────────────────────────────────────────────────────────────
BRAND_NAVY   = "#1E3A5F"
BRAND_ORANGE = "#F97316"
BRAND_WHITE  = "#FFFFFF"

# ── Approved Subject List ─────────────────────────────────────────────────────
APPROVED_SUBJECTS = [
    "Mathematics", "Science", "English", "Hindi",
    "Social_Science", "Computer", "Physics",
    "Chemistry", "Biology", "Accountancy",
    "Business_Studies", "Economics",
    "Computer_Science", "Physical_Education",
    "Environmental_Studies", "General_Knowledge",
]

# ── Valid Enums ───────────────────────────────────────────────────────────────
VALID_ROLES        = {"teacher", "principal", "accountant", "admin", "parent"}
VALID_GENDERS      = {"male", "female"}
VALID_STATUSES     = {"present", "absent"}
VALID_FEE_STATUS   = {"paid", "unpaid", "partial"}
VALID_PAY_MODES    = {"cash", "online", "cheque"}
VALID_EXAM_TYPES   = {"midterm", "final", "unit_test"}
VALID_SECTIONS     = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ")

# ── CSV Column Definitions ────────────────────────────────────────────────────
CSV_COLUMNS = {
    "students": [
        "name", "class", "section", "roll_number",
        "parent_phone", "address", "admission_date",
        "gender", "date_of_birth",
    ],
    "attendance": [
        "student_id", "date", "status", "class", "section", "marked_by",
    ],
    "marks": [
        "student_id", "subject", "exam_type",
        "marks", "max_marks", "class", "section",
    ],
    "fees": [
        "student_id", "student_name", "amount", "paid_amount",
        "due_date", "status", "payment_date", "payment_mode",
        "receipt_number",
    ],
    "staff": [
        "name", "role", "phone", "subject",
        "class_assigned", "section_assigned", "joining_date",
    ],
}

# ── Scheduler Config ──────────────────────────────────────────────────────────
MORNING_REPORT_HOUR   = 8
MORNING_REPORT_MINUTE = 0
EOD_REPORT_HOUR       = 18
EOD_REPORT_MINUTE     = 0
WEEKLY_REPORT_DAY     = "mon"   # APScheduler day-of-week
WEEKLY_REPORT_HOUR    = 9
WEEKLY_REPORT_MINUTE  = 0

# ── Thresholds ────────────────────────────────────────────────────────────────
LOW_ATTENDANCE_THRESHOLD    = 75.0   # percent
CSV_MIN_QUALITY_SCORE       = 70     # below this → reject
CSV_ERROR_REJECT_THRESHOLD  = 0.30   # 30% rows bad → reject
CONFIDENCE_MIN_THRESHOLD    = 80     # below this → add warning
COMPLAINT_OVERDUE_DAYS      = 7
SCHOOL_INACTIVE_DAYS        = 5

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR          = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FEEDBACK_LOG_PATH = os.path.join(BASE_DIR, "feedback", "feedback_log.json")
OUTPUT_DIR        = os.path.join(BASE_DIR, "output")
SAMPLE_DATA_DIR   = os.path.join(BASE_DIR, "sample_data")
